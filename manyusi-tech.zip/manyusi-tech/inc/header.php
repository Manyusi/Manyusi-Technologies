<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Manyusi Technologies - Innovative Web & Software Solutions</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css" />
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
  <div class="container">
   <marquee> <a class="navbar-brand fw-bold" href="index.php"> Welcome to Manyusi Technologies! We provide Web Development, IT Solutions, Networking & more Solution for you.</a></marquee>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="menu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php#about">About</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php#services">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php#projects">Projects</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php#contact">Contact</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php#quotation">Quotation</a></li>


        <li class="nav-item dropdown">
  <a class="nav-link dropdown-toggle" href="#" id="supportDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
    Support
  </a>
  <div class="dropdown-menu p-4 shadow" aria-labelledby="supportDropdown" style="min-width:700px;">
    <div class="row">
      <!-- Left Column -->
      <div class="col-md-6">
        <ul class="list-unstyled">
          <li class="mb-2"><i class="bi bi-tools me-2 text-primary"></i> <a href="tools.php">Tools</a></li>
          <li class="mb-2"><i class="bi bi-file-earmark-text me-2 text-success"></i> <a href="service-policy.php">Service Policy</a></li>
          <li class="mb-2"><i class="bi bi-download me-2 text-info"></i> <a href="download-center.php">Download Center</a></li>
          <li class="mb-2"><i class="bi bi-mortarboard me-2 text-warning"></i> <a href="training.php">Training</a></li>
          <li class="mb-2"><i class="bi bi-telephone me-2 text-danger"></i> <a href="hotline.php">Service Hotline</a></li>
          <li class="mb-2"><i class="bi bi-life-preserver me-2 text-primary"></i> <a href="helpdesk.php">Help Desk</a></li>
          <li class="mb-2"><i class="bi bi-megaphone me-2 text-dark"></i> <a href="announcement.php">Announcement</a></li>
        </ul>
      </div>
      <!-- Right Column -->
      <div class="col-md-6 border-start">
        <h6 class="fw-bold mb-3">Support Resources</h6>
        <ul class="list-unstyled">
          <li><a href="docs.php">📄 Documents</a></li>
          <li><a href="videos.php">🎥 Video Guides</a></li>
          <li><a href="solutions.php">💡 Solutions</a></li>
          <li><a href="faq.php">❓ FAQ</a></li>
        </ul>
        <div class="mt-3">
          <img src="assets/img/support-team.jpg" class="img-fluid rounded shadow" alt="Support">
          <p class="small mt-2 text-muted">Need assistance? Our team is here to help 24/7.</p>
        </div>
      </div>
    </div>
  </div>
</li>

      </ul>
    </div>
  </div>
</nav>
