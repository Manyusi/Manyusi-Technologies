<footer class="bg-dark text-white text-center py-4">
 <marquee> <p class="mb-0">&copy; <?php echo date('Y'); ?> Manyusi Technologies. All Rights Reserved.</p></marquee>
  <div class="mt-2">
    <a href="#" class="text-white me-3">Facebook</a>
    <a href="#" class="text-white me-3">Instagram</a>
    <a href="#" class="text-white me-3">Twiter</a>
    <a href="#" class="text-white me-3">Whatsapp</a>
    <a href="#" class="text-white me-3">LinkedIn</a>
    <a href="#" class="text-white">GitHub</a>
    
  </div>
  <div class="social-icon">
    <a href="https://facebook.com/manyusitech" target="_blank"><i class="fab fa-facebook"></i></a>
    <a href="https://instagram.com/manyusitech" target="_blank"><i class="fab fa-instagram"></i></a>
    <a href="https://twitter.com/manyusitech" target="_blank"><i class="fab fa-twitter"></i></a>
    <a href="https://youtube.com/manyusitech" target="_blank"><i class="fab fa-youtube"></i></a>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="assets/js/script.js"></script>

<script>
// 1️⃣ Create chat button
const chatbotBtn = document.createElement("div");
chatbotBtn.id = "chatbot-btn";
chatbotBtn.innerHTML = "💬";
chatbotBtn.style.position = "fixed";
chatbotBtn.style.bottom = "20px";
chatbotBtn.style.right = "20px";
chatbotBtn.style.background = "#0b74da";
chatbotBtn.style.color = "white";
chatbotBtn.style.padding = "15px";
chatbotBtn.style.borderRadius = "50%";
chatbotBtn.style.cursor = "pointer";
chatbotBtn.style.fontSize = "20px";
chatbotBtn.style.boxShadow = "0 4px 10px rgba(0,0,0,0.3)";
chatbotBtn.style.zIndex = "9999";
chatbotBtn.onclick = openChatbot;
document.body.appendChild(chatbotBtn);

// 2️⃣ Create chatbox (hidden initially)
const chatbotBox = document.createElement("div");
chatbotBox.id = "chatbot-box";
chatbotBox.style.display = "none"; // ✅ hidden initially
chatbotBox.style.position = "fixed";
chatbotBox.style.bottom = "80px";
chatbotBox.style.right = "20px";
chatbotBox.style.width = "300px";
chatbotBox.style.height = "400px";
chatbotBox.style.background = "white";
chatbotBox.style.borderRadius = "10px";
chatbotBox.style.boxShadow = "0 4px 15px rgba(0,0,0,0.3)";
chatbotBox.style.flexDirection = "column";
chatbotBox.style.zIndex = "9999";
chatbotBox.style.display = "flex";
chatbotBox.style.flexDirection = "column";
chatbotBox.style.overflow = "hidden";
chatbotBox.style.visibility = "hidden"; // extra safety
document.body.appendChild(chatbotBox);

// 3️⃣ Header with close button
const header = document.createElement("div");
header.innerHTML = `Manyusi Chatbot <span style="cursor:pointer;">✖</span>`;
header.style.background = "#0b74da";
header.style.color = "white";
header.style.padding = "10px";
header.style.fontWeight = "bold";
header.style.display = "flex";
header.style.justifyContent = "space-between";
header.style.alignItems = "center";
chatbotBox.appendChild(header);

// Close button
header.querySelector("span").onclick = closeChatbot;

// 4️⃣ Messages container
const messages = document.createElement("div");
messages.id = "chatbot-messages";
messages.style.flex = "1";
messages.style.padding = "10px";
messages.style.overflowY = "auto";
messages.style.fontSize = "14px";
chatbotBox.appendChild(messages);

// 5️⃣ Input box
const input = document.createElement("input");
input.id = "chatbot-input";
input.placeholder = "Ask me something...";
input.style.border = "none";
input.style.borderTop = "1px solid #ddd";
input.style.padding = "10px";
input.style.width = "100%";
input.style.outline = "none";
input.addEventListener("keypress", function(e){
  if(e.key === "Enter") sendMessage();
});
chatbotBox.appendChild(input);

// 6️⃣ Functions
function openChatbot() {
  chatbotBox.style.display = "flex"; 
  chatbotBox.style.visibility = "visible"; // ensure visible only on click
}

function closeChatbot() {
  chatbotBox.style.display = "none";
  chatbotBox.style.visibility = "hidden";
}

function sendMessage(){
  let userMsg = input.value.trim();
  if(userMsg === "") return;

  messages.innerHTML += `<div class='user'>${userMsg}</div>`;

  let botReply = "Sorry, I don't understand that yet.";
  let msg = userMsg.toLowerCase();

  if(msg.includes("hello") || msg.includes("hi")) botReply = "Hi 👋 Welcome to Manyusi Technologies. How can I help you?";
  else if(msg.includes("services")) botReply = "We offer: Web Development, Software Development, Networking, Cybersecurity, and IT Consultancy.";
  else if(msg.includes("contact")) botReply = "You can reach us at hr@manyusitech.com or WhatsApp +255712345678.";
  else if(msg.includes("price") || msg.includes("cost")) botReply = "Our pricing starts at $199 for Basic websites. Check the Pricing section.";
  else if(msg.includes("career") || msg.includes("job")) botReply = "Visit the Careers section to apply for jobs at Manyusi Technologies.";
  else if(msg.includes("training")) botReply = "Yes! We provide training in Web Development, Networking, and IT skills.";

  messages.innerHTML += `<div class='bot'>${botReply}</div>`;
  messages.scrollTop = messages.scrollHeight;
  input.value = "";
}

// 7️⃣ Basic styling for messages
const style = document.createElement("style");
style.innerHTML = `
.bot { color: #0b74da; margin: 5px 0; }
.user { color: #333; text-align: right; margin: 5px 0; }
`;
document.head.appendChild(style);
</script>





</body>
</html>
