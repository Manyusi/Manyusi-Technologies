AOS.init({
  duration: 1000,
  once: true
});


document.querySelectorAll('.solution-card').forEach(card => {
  card.addEventListener('click', () => {
    const solutionId = card.id;
    // Load detailed information based on solutionId
    // This could involve navigating to a new page or updating the current page content
  });
});

document.addEventListener("DOMContentLoaded", function(){
  const header = document.createElement("header");
  header.id = "site-header";
  Object.assign(header.style,{
    background:"#0b74da",
    color:"white",
    padding:"15px",
    textAlign:"center",
    fontSize:"20px",
    fontWeight:"bold"
  });

  const marquee = document.createElement("marquee");
  marquee.behavior = "scroll";
  marquee.direction = "left";
  marquee.scrollAmount = 6;
  marquee.innerText = "Welcome to Manyusi Technologies! We provide Web Development, IT Solutions, Networking & more.";

  header.appendChild(marquee);
  document.body.prepend(header);
});
